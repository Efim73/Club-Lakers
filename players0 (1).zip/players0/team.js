let gallery = document.getElementsByClassName('gallery')[0];
console.log(gallery);
let flatInfo = document.getElementsByClassName('flatInfo')[0];
console.log(flatInfo);
let iframe = document.getElementsByTagName('iframe');


iframe.style.height=gallery.offsetHeight-flatInfo.offsetHeight-15-iframe.style.marginBotton+'px';